//
//  main.cpp
//  get_started
//
//  Created by lco on 19/04/20.
//  Copyright © 2020 lco. All rights reserved.
//

#include <iostream>
#include <string>
using namespace std;

class User{

    int _secret = 22;
    
public:
    string name = "default";
    void classMessage(){cout << "Class is great, " << name << endl;}
    void setSecert(const int & newsecret){_secret = newsecret;}
    int getSecret(){return _secret;}
    
};


int main()
{
   
    User sam;
    sam.name = "Sam";
    sam.classMessage();
    sam.setSecert(333);
    
    cout << sam.getSecret() << endl;
    
    
    
    User hitesh;
    hitesh.classMessage();
    hitesh.name = "hitesh";
    hitesh.classMessage();
    
    
    return 0;
}
