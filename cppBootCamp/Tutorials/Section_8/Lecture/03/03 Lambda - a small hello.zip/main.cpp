//
//  main.cpp
//  get_started
//
//  Created by lco on 19/04/20.
//  Copyright © 2020 lco. All rights reserved.


#include <iostream>
#include <string>


using namespace std;



int main()
 {

     []{cout << "Hello LearnCodeOnline.in\n";}();
     [](){return 100;};
     
     auto sum = [](auto a, auto b){return a + b;};
     
     cout << "SUm of 2 and 5 is: " << sum(2, 5) << endl;
     cout << "SUm of 2.5 and 5.5 is: " << sum(2.5, 5.5) << endl;
     
     string a = "abc";
     string b = "def";
     cout << sum(a, b) << endl;
     
    return 0;
 }
