//
//  main.cpp
//  get_started
//
//  Created by lco on 19/04/20.
//  Copyright © 2020 lco. All rights reserved.


#include <iostream>
#include <string>


using namespace std;



int main()
 {

     static const char * originalfile = "originalFile.txt";
     static const char * editedfile = "editedFile.txt";
     
//     rename(originalfile, editedfile);
     remove(editedfile);
     
//     FILE * fh = fopen(originalfile, "w");
//     fclose(fh);
     
     
    return 0;
 }
