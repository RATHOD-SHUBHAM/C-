//
//  main.cpp
//  get_started
//
//  Created by lco on 19/04/20.
//  Copyright © 2020 lco. All rights reserved.


#include <iostream>
#include <string>

using namespace std;

void swap(int &a, int &b){
    
    int tmp = move(a);
    a = move(b);
    b = move(tmp);
}

string printMe(){
    return "I am print";
}

int main()
{
    int a =  3;
    int b = 4;
    
    swap(a, b);
    
    cout << "A : " << a << endl;
    
    string s = printMe();
    
    string&& ss = printMe();
    
    return 0;
    
}
