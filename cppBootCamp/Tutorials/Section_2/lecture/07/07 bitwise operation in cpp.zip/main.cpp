//
//  main.cpp
//  get_started
//
//  Created by lco on 19/04/20.
//  Copyright © 2020 lco. All rights reserved.
//




#include <iostream>
using namespace std;

int main() {
    
    unsigned int x = 6;
    unsigned int y = 7;
    
    unsigned int z = y >> 1;
    
    cout << "Value of z is: " << z << endl;
    
    
    return 0;
}


