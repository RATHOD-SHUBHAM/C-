//
//  main.cpp
//  stl
//
//  Created by lco on 27/04/20.
//  Copyright © 2020 lco. All rights reserved.
//

#include <iostream>
using namespace std;

class MyFloat{
    float ft;
public:
    MyFloat(){
        ft = 0.1;
    }
    void getValue(){
        cout << ft << endl;
    }
    void operator ()(float v){
        ft += v;
    }
};

int main() {
    
    MyFloat floaty;
    floaty.getValue();
    
    floaty(1);
    floaty.getValue();
    
    floaty(1.3);
    floaty.getValue();
   
    return 0;
}
