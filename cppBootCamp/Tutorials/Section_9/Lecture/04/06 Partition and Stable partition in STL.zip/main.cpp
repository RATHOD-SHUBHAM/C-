//
//  main.cpp
//  stl
//
//  Created by lco on 27/04/20.
//  Copyright © 2020 lco. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;



int main() {
    
    vector<int> myints = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    
    for (int x: myints){
        cout<< x << " ";
    }
    cout << "\n";
    
    partition(begin(myints), myints.end(), [](auto x){ return x%2==0;});
    for (int x: myints){
        cout<< x << " ";
    }
    cout << "\n";
    
    return 0;
}
