//
//  main.cpp
//  stl
//
//  Created by lco on 27/04/20.
//  Copyright © 2020 lco. All rights reserved.
//

#include <iostream>
using namespace std;

template <typename T>
T getBigger(T a, T b){
  return (a > b) ? a : b;
}

int main() {
    
    cout << getBigger('a', 'b') << endl;
    
    return 0;
}
