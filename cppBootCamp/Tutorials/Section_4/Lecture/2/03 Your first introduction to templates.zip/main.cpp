//
//  main.cpp
//  get_started
//
//  Created by lco on 19/04/20.
//  Copyright © 2020 lco. All rights reserved.
//

#include <iostream>

using namespace std;
  
void lifeUp(int &life){
    ++life;
}

template<typename T>

T addme(T a, T b){
    return a + b;
}

int main() {
    int life = 3;
    lifeUp(life);
    cout << life << endl;
    
    int v1 = 4;
    int v2 = 5;
    float v3 = 5.6;
    float v4 = 7.5;
    
    cout << addme(v3, v4) << endl;

    return 0;
}


