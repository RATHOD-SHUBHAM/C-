//
//  main.cpp
//  get_started
//
//  Created by lco on 19/04/20.
//  Copyright © 2020 lco. All rights reserved.
//

#include <iostream>
#include <string>

#define END return 0
#define ENDMESSAGE cout << "Program ends here\n"

#define LCOINT int8_t
#define LCOCCPC const char* const

#define console_log(a) cout << a << endl


using namespace std;


int main()
{
    
    int score = 400;
    console_log(score);
    
    string name = "hitesh";
    console_log(name);
    
    ENDMESSAGE;
    END;
    
}
