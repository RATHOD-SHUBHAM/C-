//
//  main.cpp
//  get_started
//
//  Created by lco on 19/04/20.
//  Copyright © 2020 lco. All rights reserved.
//

#include <iostream>

using namespace std;
  
int getTwo(){
    return 2;
}

void intersting(){
    puts("I am interesting");
}

int main() {
    int whatIgot = getTwo();
    
    void (*pointsToInteresting)() = intersting;
    
    cout << whatIgot << endl;
    pointsToInteresting();
    (*pointsToInteresting)();
    return 0;
}


