//
//  adder.h
//  get_started
//
//  Created by lco on 22/04/20.
//  Copyright © 2020 lco. All rights reserved.
//

#ifndef adder_h
#define adder_h

int addme(int a, int b){
    return a + b;
}

float addme(float a, float b){
    return a + b;
}



#endif /* adder_h */
