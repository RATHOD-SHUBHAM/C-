//
//  main.cpp
//  get_started
//
//  Created by lco on 19/04/20.
//  Copyright © 2020 lco. All rights reserved.
//

#include <iostream>
#include <string>


using namespace std;

template <typename T>
void func(T t){
    cout << "One func "<< t << endl;
}

template<typename T, typename... Args>
void func(T t, Args... args){
    cout << "Two Func "<< t << endl;
    func(args...);
}

int main()
{
    
    string myName = "hitesh";
    
    func(1);
    func(1, 2, 3.4, 4.5, myName);
    return 0;
}
