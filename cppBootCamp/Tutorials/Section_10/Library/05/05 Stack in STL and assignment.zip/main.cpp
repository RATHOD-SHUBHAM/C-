//
//  main.cpp
//  stl
//
//  Created by lco on 27/04/20.
//  Copyright © 2020 lco. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <stack>

using namespace std;

int main() {
    
    stack<int> mystack;
    
    mystack.push(10);
    mystack.push(12);
    mystack.push(14);
    mystack.push(15);
    
    cout << mystack.size() << endl;
    cout << mystack.top() << endl;
    
    mystack.pop();
    
    cout << mystack.top() << endl;
    
    while (!mystack.empty()) {
        cout << " " << mystack.top();
        mystack.pop();
    }
    cout << "\n";
    
    return 0;
}
