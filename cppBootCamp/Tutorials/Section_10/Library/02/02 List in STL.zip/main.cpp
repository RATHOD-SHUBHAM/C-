//
//  main.cpp
//  stl
//
//  Created by lco on 27/04/20.
//  Copyright © 2020 lco. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <list>

using namespace std;

int main() {
    
    list<int> mylist;
    
    for (int i = 3; i <= 10; ++i) {
        mylist.push_back(i);
    }
    
    cout << mylist.front() << endl;
    
    cout << mylist.back() << endl;
    
    mylist.pop_back();
    
    mylist.reverse();
    
    for (auto i : mylist) {
        cout << i << " ";
    }
    cout << endl;
    
    mylist.sort();
    for (auto i : mylist) {
        cout << i << " ";
    }
    cout << endl;
    
    return 0;
}
