//
//  main.cpp
//  get_started
//
//  Created by lco on 19/04/20.
//  Copyright © 2020 lco. All rights reserved.


#include <iostream>
#include <string>
using namespace std;

class One{
public:
    virtual void intro(){
        cout << "I am One\n";
    }
};

class Two: public One{
public:
    void intro(){
        cout << "I am Two\n";
    }
};

class Three: public One{
public:
    void intro(){
        cout << "I am Three\n";
    }
};



int main()
{
    One *a;
    Two b;
    Three c;
  
    a = &b;
    a->intro();
    
    
    a = &c;
    a->intro();
    return 0;
    
}
